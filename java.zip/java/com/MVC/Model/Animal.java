package com.MVC.Model;

public class Animal {
	int a_id;
	String a_name;
	int a_age;
	String a_gender;
	double a_cost;
	String a_lifespan;
	String a_image;
	public int getA_id() {
		return a_id;
	}
	public void setA_id(int a_id) {
		this.a_id = a_id;
	}
	public String getA_name() {
		return a_name;
	}
	public void setA_name(String a_name) {
		this.a_name = a_name;
	}
	public int getA_age() {
		return a_age;
	}
	public void setA_age(int a_age) {
		this.a_age = a_age;
	}
	public String getA_gender() {
		return a_gender;
	}
	public void setA_gender(String a_gender) {
		this.a_gender = a_gender;
	}
	public double getA_cost() {
		return a_cost;
	}
	public void setA_cost(double a_cost) {
		this.a_cost = a_cost;
	}
	public String getA_lifespan() {
		return a_lifespan;
	}
	public void setA_lifespan(String a_lifespan) {
		this.a_lifespan = a_lifespan;
	}
	public String getA_image() {
		return a_image;
	}
	public void setA_image(String a_image) {
		this.a_image = a_image;
	}
	

}
