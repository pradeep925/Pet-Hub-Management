package com.MVC.Model;

public class Wishlist {
	String w_id;
	  String w_image;
	  String w_name;
	  String w_cost;
	public String getW_id() {
		return w_id;
	}
	public void setW_id(String w_id) {
		this.w_id = w_id;
	}
	public String getW_image() {
		return w_image;
	}
	public void setW_image(String w_image) {
		this.w_image = w_image;
	}
	public String getW_name() {
		return w_name;
	}
	public void setW_name(String w_name) {
		this.w_name = w_name;
	}
	public String getW_cost() {
		return w_cost;
	}
	public void setW_cost(String w_cost) {
		this.w_cost = w_cost;
	}
	

}